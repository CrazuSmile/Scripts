#!/bin/bash
a=1
while [ "$a" -lt 101 ]; do
    echo "$a"
    ((a++))  
done